{
  "version": "1.2",
  "dbname": "respiratory_panel_dx.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "respiratory_panel_dx.fasta",
  "number-of-letters": 11254418,
  "number-of-sequences": 57,
  "last-updated": "2026-05-20T09:16:00",
  "number-of-volumes": 1,
  "bytes-total": 2861588,
  "bytes-to-cache": 2814507,
  "files": [
    "respiratory_panel_dx.fasta.ndb",
    "respiratory_panel_dx.fasta.nhr",
    "respiratory_panel_dx.fasta.nin",
    "respiratory_panel_dx.fasta.not",
    "respiratory_panel_dx.fasta.nsq",
    "respiratory_panel_dx.fasta.ntf",
    "respiratory_panel_dx.fasta.nto"
  ]
}
