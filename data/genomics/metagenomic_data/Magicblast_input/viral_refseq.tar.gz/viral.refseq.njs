{
  "version": "1.2",
  "dbname": "viral.refseq",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "combined_viral_refseq.fasta",
  "number-of-letters": 1609169,
  "number-of-sequences": 42,
  "last-updated": "2026-08-19T15:59:00",
  "number-of-volumes": 1,
  "bytes-total": 458970,
  "bytes-to-cache": 403011,
  "files": [
    "viral.refseq.ndb",
    "viral.refseq.nhr",
    "viral.refseq.nin",
    "viral.refseq.nog",
    "viral.refseq.nos",
    "viral.refseq.not",
    "viral.refseq.nsq",
    "viral.refseq.ntf",
    "viral.refseq.nto"
  ]
}
