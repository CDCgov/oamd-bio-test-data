{
  "version": "1.2",
  "dbname": "neiss_nucl",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "neiss_nucl.fasta",
  "number-of-letters": 4965,
  "number-of-sequences": 5,
  "last-updated": "2025-11-05T15:23:00",
  "number-of-volumes": 1,
  "bytes-total": 38735,
  "bytes-to-cache": 1414,
  "files": [
    "neiss_nucl.ndb",
    "neiss_nucl.nhr",
    "neiss_nucl.nin",
    "neiss_nucl.not",
    "neiss_nucl.nsq",
    "neiss_nucl.ntf",
    "neiss_nucl.nto"
  ]
}
