{
  "version": "1.2",
  "dbname": "haem_nucl",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "haem_nucl.fasta",
  "number-of-letters": 15186,
  "number-of-sequences": 5,
  "last-updated": "2025-11-05T15:23:00",
  "number-of-volumes": 1,
  "bytes-total": 41281,
  "bytes-to-cache": 3960,
  "files": [
    "haem_nucl.ndb",
    "haem_nucl.nhr",
    "haem_nucl.nin",
    "haem_nucl.not",
    "haem_nucl.nsq",
    "haem_nucl.ntf",
    "haem_nucl.nto"
  ]
}
