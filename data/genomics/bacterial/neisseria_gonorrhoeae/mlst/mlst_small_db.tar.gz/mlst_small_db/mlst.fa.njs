{
  "version": "1.2",
  "dbname": "mlst.fa",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "PubMLST",
  "number-of-letters": 4289707,
  "number-of-sequences": 9138,
  "last-updated": "2025-11-25T11:14:00",
  "number-of-volumes": 1,
  "bytes-total": 2939932,
  "bytes-to-cache": 1188652,
  "files": [
    "mlst.fa.ndb",
    "mlst.fa.nhd",
    "mlst.fa.nhi",
    "mlst.fa.nhr",
    "mlst.fa.nin",
    "mlst.fa.nog",
    "mlst.fa.nos",
    "mlst.fa.not",
    "mlst.fa.nsq",
    "mlst.fa.ntf",
    "mlst.fa.nto"
  ]
}
