{
  "version": "1.2",
  "dbname": "all_loci.fasta",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "/scicomp/home-pure/ptx4/db/all_loci.fasta",
  "number-of-letters": 224648,
  "number-of-sequences": 609,
  "last-updated": "2026-06-17T13:26:00",
  "number-of-volumes": 1,
  "bytes-total": 193101,
  "bytes-to-cache": 64015,
  "files": [
    "all_loci.fasta.ndb",
    "all_loci.fasta.nhr",
    "all_loci.fasta.nin",
    "all_loci.fasta.nog",
    "all_loci.fasta.nos",
    "all_loci.fasta.not",
    "all_loci.fasta.nsq",
    "all_loci.fasta.ntf",
    "all_loci.fasta.nto"
  ]
}
