{
  "version": "1.2",
  "dbname": "AMR_DNA-Klebsiella_oxytoca",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "AMR_DNA-Klebsiella_oxytoca",
  "number-of-letters": 103,
  "number-of-sequences": 1,
  "last-updated": "2024-03-12T15:58:00",
  "number-of-volumes": 1,
  "bytes-total": 37185,
  "bytes-to-cache": 171,
  "files": [
    "AMR_DNA-Klebsiella_oxytoca.ndb",
    "AMR_DNA-Klebsiella_oxytoca.nhr",
    "AMR_DNA-Klebsiella_oxytoca.nin",
    "AMR_DNA-Klebsiella_oxytoca.not",
    "AMR_DNA-Klebsiella_oxytoca.nsq",
    "AMR_DNA-Klebsiella_oxytoca.ntf",
    "AMR_DNA-Klebsiella_oxytoca.nto"
  ]
}
