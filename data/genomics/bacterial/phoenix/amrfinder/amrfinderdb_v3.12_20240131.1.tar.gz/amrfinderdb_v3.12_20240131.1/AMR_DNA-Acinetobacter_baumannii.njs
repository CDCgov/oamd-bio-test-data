{
  "version": "1.2",
  "dbname": "AMR_DNA-Acinetobacter_baumannii",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "AMR_DNA-Acinetobacter_baumannii",
  "number-of-letters": 231,
  "number-of-sequences": 1,
  "last-updated": "2024-03-12T15:58:00",
  "number-of-volumes": 1,
  "bytes-total": 37233,
  "bytes-to-cache": 211,
  "files": [
    "AMR_DNA-Acinetobacter_baumannii.ndb",
    "AMR_DNA-Acinetobacter_baumannii.nhr",
    "AMR_DNA-Acinetobacter_baumannii.nin",
    "AMR_DNA-Acinetobacter_baumannii.not",
    "AMR_DNA-Acinetobacter_baumannii.nsq",
    "AMR_DNA-Acinetobacter_baumannii.ntf",
    "AMR_DNA-Acinetobacter_baumannii.nto"
  ]
}
