{
  "version": "1.2",
  "dbname": "AMR_CDS",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "AMR_CDS",
  "number-of-letters": 8187001,
  "number-of-sequences": 8038,
  "last-updated": "2024-03-12T15:56:00",
  "number-of-volumes": 1,
  "bytes-total": 3834375,
  "bytes-to-cache": 2149060,
  "files": [
    "AMR_CDS.ndb",
    "AMR_CDS.nhr",
    "AMR_CDS.nin",
    "AMR_CDS.not",
    "AMR_CDS.nsq",
    "AMR_CDS.ntf",
    "AMR_CDS.nto"
  ]
}
