{
  "version": "1.2",
  "dbname": "AMR_DNA-Escherichia",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "AMR_DNA-Escherichia",
  "number-of-letters": 7412,
  "number-of-sequences": 5,
  "last-updated": "2024-03-12T15:58:00",
  "number-of-volumes": 1,
  "bytes-total": 39585,
  "bytes-to-cache": 2041,
  "files": [
    "AMR_DNA-Escherichia.ndb",
    "AMR_DNA-Escherichia.nhr",
    "AMR_DNA-Escherichia.nin",
    "AMR_DNA-Escherichia.not",
    "AMR_DNA-Escherichia.nsq",
    "AMR_DNA-Escherichia.ntf",
    "AMR_DNA-Escherichia.nto"
  ]
}
