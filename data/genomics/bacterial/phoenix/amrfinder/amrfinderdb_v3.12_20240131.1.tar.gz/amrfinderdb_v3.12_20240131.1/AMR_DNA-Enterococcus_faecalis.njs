{
  "version": "1.2",
  "dbname": "AMR_DNA-Enterococcus_faecalis",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "AMR_DNA-Enterococcus_faecalis",
  "number-of-letters": 2896,
  "number-of-sequences": 1,
  "last-updated": "2024-03-12T15:58:00",
  "number-of-volumes": 1,
  "bytes-total": 37882,
  "bytes-to-cache": 878,
  "files": [
    "AMR_DNA-Enterococcus_faecalis.ndb",
    "AMR_DNA-Enterococcus_faecalis.nhr",
    "AMR_DNA-Enterococcus_faecalis.nin",
    "AMR_DNA-Enterococcus_faecalis.not",
    "AMR_DNA-Enterococcus_faecalis.nsq",
    "AMR_DNA-Enterococcus_faecalis.ntf",
    "AMR_DNA-Enterococcus_faecalis.nto"
  ]
}
