{
  "version": "1.2",
  "dbname": "AMR_DNA-Salmonella",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "AMR_DNA-Salmonella",
  "number-of-letters": 1536,
  "number-of-sequences": 1,
  "last-updated": "2024-03-12T15:59:00",
  "number-of-volumes": 1,
  "bytes-total": 37523,
  "bytes-to-cache": 514,
  "files": [
    "AMR_DNA-Salmonella.ndb",
    "AMR_DNA-Salmonella.nhr",
    "AMR_DNA-Salmonella.nin",
    "AMR_DNA-Salmonella.not",
    "AMR_DNA-Salmonella.nsq",
    "AMR_DNA-Salmonella.ntf",
    "AMR_DNA-Salmonella.nto"
  ]
}
