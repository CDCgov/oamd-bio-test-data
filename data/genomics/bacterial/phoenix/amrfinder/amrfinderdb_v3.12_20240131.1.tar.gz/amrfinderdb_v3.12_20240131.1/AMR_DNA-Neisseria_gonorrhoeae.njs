{
  "version": "1.2",
  "dbname": "AMR_DNA-Neisseria_gonorrhoeae",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "AMR_DNA-Neisseria_gonorrhoeae",
  "number-of-letters": 5561,
  "number-of-sequences": 6,
  "last-updated": "2024-03-12T15:59:00",
  "number-of-volumes": 1,
  "bytes-total": 39385,
  "bytes-to-cache": 1607,
  "files": [
    "AMR_DNA-Neisseria_gonorrhoeae.ndb",
    "AMR_DNA-Neisseria_gonorrhoeae.nhr",
    "AMR_DNA-Neisseria_gonorrhoeae.nin",
    "AMR_DNA-Neisseria_gonorrhoeae.not",
    "AMR_DNA-Neisseria_gonorrhoeae.nsq",
    "AMR_DNA-Neisseria_gonorrhoeae.ntf",
    "AMR_DNA-Neisseria_gonorrhoeae.nto"
  ]
}
