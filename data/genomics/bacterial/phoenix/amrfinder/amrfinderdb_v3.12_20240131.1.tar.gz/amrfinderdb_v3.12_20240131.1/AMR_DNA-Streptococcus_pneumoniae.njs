{
  "version": "1.2",
  "dbname": "AMR_DNA-Streptococcus_pneumoniae",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "AMR_DNA-Streptococcus_pneumoniae",
  "number-of-letters": 2904,
  "number-of-sequences": 1,
  "last-updated": "2024-03-12T15:59:00",
  "number-of-volumes": 1,
  "bytes-total": 37890,
  "bytes-to-cache": 888,
  "files": [
    "AMR_DNA-Streptococcus_pneumoniae.ndb",
    "AMR_DNA-Streptococcus_pneumoniae.nhr",
    "AMR_DNA-Streptococcus_pneumoniae.nin",
    "AMR_DNA-Streptococcus_pneumoniae.not",
    "AMR_DNA-Streptococcus_pneumoniae.nsq",
    "AMR_DNA-Streptococcus_pneumoniae.ntf",
    "AMR_DNA-Streptococcus_pneumoniae.nto"
  ]
}
