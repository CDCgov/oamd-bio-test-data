{
  "version": "1.2",
  "dbname": "AMR_DNA-Clostridioides_difficile",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "AMR_DNA-Clostridioides_difficile",
  "number-of-letters": 2900,
  "number-of-sequences": 1,
  "last-updated": "2024-03-12T15:58:00",
  "number-of-volumes": 1,
  "bytes-total": 37893,
  "bytes-to-cache": 887,
  "files": [
    "AMR_DNA-Clostridioides_difficile.ndb",
    "AMR_DNA-Clostridioides_difficile.nhr",
    "AMR_DNA-Clostridioides_difficile.nin",
    "AMR_DNA-Clostridioides_difficile.not",
    "AMR_DNA-Clostridioides_difficile.nsq",
    "AMR_DNA-Clostridioides_difficile.ntf",
    "AMR_DNA-Clostridioides_difficile.nto"
  ]
}
