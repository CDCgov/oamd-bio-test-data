{
  "version": "1.2",
  "dbname": "mlst.fa",
  "dbtype": "Nucleotide",
  "db-version": 5,
  "description": "PubMLST",
  "number-of-letters": 92672455,
  "number-of-sequences": 194769,
  "last-updated": "2024-01-24T10:44:00",
  "number-of-volumes": 1,
  "bytes-total": 62343764,
  "bytes-to-cache": 25678337,
  "files": [
    "mlst.fa.ndb",
    "mlst.fa.nhd",
    "mlst.fa.nhi",
    "mlst.fa.nhr",
    "mlst.fa.nin",
    "mlst.fa.nog",
    "mlst.fa.nos",
    "mlst.fa.not",
    "mlst.fa.nsq",
    "mlst.fa.ntf",
    "mlst.fa.nto"
  ]
}
